package gamedrawer;

import javafx.scene.canvas.GraphicsContext;

public class ProgressBarDrawer {
	GraphicsContext gc;
	
	public ProgressBarDrawer(GraphicsContext gc) {
		this.gc = gc;
	}
	
	public void draw() {
		
	}
}
